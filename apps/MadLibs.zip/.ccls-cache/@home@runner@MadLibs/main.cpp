#include <iostream>
#include <fstream>
#include <string>
using namespace std;

void replaceWord(string story, string word, string replace){
  while (story.find(word) != string::npos){
        story.replace(story.find(word), word.length(), replace);
      }
}

int main() {
  int stories;
  int wordnum;
  int counter = 0;
  string words[wordnum];
  ifstream file;
  file.open("stories.txt");
  string story;
  string line;
  
  cout << " ____    ____               __  _____      _   __\n";
  cout << "|_   \\  /   _|             |  ]|_   _|    (_) [  |\n";
  cout << "  |   \\/   |   ,--.    .--.| |   | |      __   | |.--.   .--.\n";
  cout << "  | |\\  /| |  `'_\\ : / /'`\\' |   | |   _ [  |  | '/'`\\ \\( (`\\]\n";
  cout << " _| |_\\/_| |_ // | |,| \\__/  |  _| |__/ | | |  |  \\__/ | `'.'.\n";
  cout << "|_____||_____|\\'-;__/ '.__.;__]|________|[___][__;.__.' [\\__) )\n";
  cout << "Welcome to Mad Libs! Choose a story to begin!" << endl << "Type 1 for \"Food Day\"" << endl << "Type 2 for \"Summer Love Story\"" << endl << "Type 3 for \"STORY3\"" << endl << "(Type 4 to skip to end screen)" << endl;
  
  bool play = 1;
  while(play){
    
    if(counter > 0){
      cout << "Choose another story!" << endl << "Type 1 for \"Food Day\"" << endl << "Type 2 for \"Summer Love Story\"" << endl << "Type 3 for \"STORY3\"" << endl << "(Type 4 to skip to end screen)" << endl;
    }
    cin >> stories;
    
    switch (stories) {
      case 1:
        for(int i = 1; getline(file, line) && i < 4; i++){
          if(i == 1){
            story = line;
          }
        }
      case 2:
        for(int i = 1; getline(file, line) && i < 4; i++){
          if(i == 2){
            story = line;
          }
        }
      case 3:
        for(int i = 1; getline(file, line) && i < 4; i++){
          if(i == 3){
            story = line;
          }
        }
    }

    counter++;
    if(stories == 1){ 
      cout << "As the prompts come up, fill each with a random word to fill the blanks and allow hilarity to ensue." << endl;
      wordnum = 8;
      
      cout << "Enter a food: ";
      cin >> words[0];
      replaceWord(story, "<FOOD>", words[0]);
      
      cout << "Enter a name: ";
      cin >> words[1];
      replaceWord(story, "<NAME>", words[1]);
      
      cout << "Enter an emotion: ";
      cin >> words[2];
      replaceWord(story, "<EMOTION>", words[2]);
      
      cout << "Enter a noun: ";
      cin >> words[3];
      replaceWord(story, "<NOUN1>", words[3]);
      
      cout << "Enter another noun: ";
      cin >> words[7];
      replaceWord(story, "<NOUN2>", words[7]);
      
      cout << "Enter a verb (past-tense): ";
      cin >> words[4];
      replaceWord(story, "<VERB1>", words[4]);
      
      cout << "Enter another verb (past-tense): ";
      cin >> words[5];
      replaceWord(story, "<VERB2>", words[5]);
      
      cout << "Enter another verb (past-tense): ";
      cin >> words[6];
      replaceWord(story, "<VERB3>", words[6]);
      
      cout << endl << story << endl;
      
    }else if(stories == 2){
      cout << "As the prompts come up, fill each with a random word to fill the blanks and allow hilarity to ensue." << endl;
      wordnum = 20;
      cout << "Enter a guy's name: ";
      cin >> words[0];
      replaceWord(story, "<NAME1>", words[0]);
      
      cout << "Enter a girl's name: ";
      cin >> words[1];
      replaceWord(story, "<NAME2>", words[1]);
      
      cout << "Enter a noun: ";
      cin >> words[2];
      replaceWord(story, "<NOUN1>", words[2]);
      
      cout << "Enter another noun: ";
      cin >> words[4];
      replaceWord(story, "<NOUN2>", words[4]);
      
      cout << "Enter a proper noun: ";
      cin >> words[11];
      replaceWord(story, "<NOUN3>", words[11]);

      cout << "Enter a body part: ";
      cin >> words[3];
      replaceWord(story, "<BODY1>", words[3]);

      cout << "Enter another body part: ";
      cin >> words[13];
      replaceWord(story, "<BODY2>", words[13]);

      cout << "Enter a verb (past-tense): ";
      cin >> words[6];
      replaceWord(story, "<VERB1>", words[6]);

      cout << "Enter another verb (past-tense): ";
      cin >> words[10];
      replaceWord(story, "<VERB2>", words[10]);

      cout << "Enter another verb (past-tense): ";
      cin >> words[12];
      replaceWord(story, "<VERB3>", words[12]);

      cout << "Enter an animal: ";
      cin >> words[5];
      replaceWord(story, "<ANIMAL>", words[5]);

      cout << "Enter an adjective: ";
      cin >> words[9];
      replaceWord(story, "<ADJ1>", words[9]);

      cout << "Enter another adjective: ";
      cin >> words[15];
      replaceWord(story, "<ADJ2>", words[15]);

      cout << "Enter another adjective: ";
      cin >> words[19];
      replaceWord(story, "<ADJ3>", words[19]);

      cout << "Enter a place: ";
      cin >> words[13];
      replaceWord(story, "<PLACE>", words[13]);

      cout << "Enter an adverb: ";
      cin >> words[17];
      replaceWord(story, "<ADV>", words[17]);

      cout << "Enter a catchphrase: ";
      cin >> words[7];
      replaceWord(story, "<PHRASE>", words[7]);

      cout << "Enter an emotion: ";
      cin >> words[8];
      replaceWord(story, "<EMOTION1>", words[8]);

      cout << "Enter another emotion: ";
      cin >> words[16];
      replaceWord(story, "<EMOTION2>", words[16]);

      cout << "Enter a song title: ";
      cin >> words[18];
      replaceWord(story, "<SONG>", words[18]);
      
      cout << endl << story << endl;
      
    }else if(stories == 3){
      // cout << "As the prompts come up, fill each with a random word to fill the blanks and allow hilarity to ensue." << endl;
      cout << "Under construction!" << endl;
    }else if(stories == 4){
      cout << "Skipped!\n";
    }else{
      cout << "Invalid response, try again!\n";
    }

    if(counter > 0){
      cout << endl << "Would you like to try another story? (Y/N)\n";
      char yn;
      cin >> yn;
      if(yn == 'Y'||yn == 'y'){
        cout << endl;
        counter++;
      }else if(yn == 'N'||yn == 'n'){
        play = 0;
      }else{
        cout << "Invalid response, try again!\n";
      }
    }
  }
  cout << " ____    ____               __  _____      _   __\n";
  cout << "|_   \\  /   _|             |  ]|_   _|    (_) [  |\n";
  cout << "  |   \\/   |   ,--.    .--.| |   | |      __   | |.--.   .--.\n";
  cout << "  | |\\  /| |  `'_\\ : / /'`\\' |   | |   _ [  |  | '/'`\\ \\( (`\\]\n";
  cout << " _| |_\\/_| |_ // | |,| \\__/  |  _| |__/ | | |  |  \\__/ | `'.'.\n";
  cout << "|_____||_____|\\'-;__/ '.__.;__]|________|[___][__;.__.' [\\__) )\n";
  cout << "Thanks for playing!\nCreated by Duncan Kyle 2022. Mad Libs stories found online, all rights reserved.";
  return 0;
}