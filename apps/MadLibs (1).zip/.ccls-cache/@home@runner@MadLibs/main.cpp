#include <iostream>
#include <fstream>
#include <string>
using namespace std;

void replaceWord(string story, string word, int letters, string replace){
  while (story.find(word) != string::npos){
        story.replace(story.find(word), letters, replace);
      }
}

int main() {
  int stories;
  int wordnum;
  int counter = 0;
  string words[wordnum];
  ifstream file;
  file.open("stories.txt");
  string story;
  string line;
  
  cout << " ____    ____               __  _____      _   __\n";
  cout << "|_   \\  /   _|             |  ]|_   _|    (_) [  |\n";
  cout << "  |   \\/   |   ,--.    .--.| |   | |      __   | |.--.   .--.\n";
  cout << "  | |\\  /| |  `'_\\ : / /'`\\' |   | |   _ [  |  | '/'`\\ \\( (`\\]\n";
  cout << " _| |_\\/_| |_ // | |,| \\__/  |  _| |__/ | | |  |  \\__/ | `'.'.\n";
  cout << "|_____||_____|\\'-;__/ '.__.;__]|________|[___][__;.__.' [\\__) )\n";
  cout << "Welcome to Mad Libs! Choose a story to begin!" << endl << "Type 1 for \"Food Day\"" << endl << "Type 2 for \"Summer Love Story\"" << endl << "Type 3 for \"STORY3\"" << endl << "(Type 4 to skip to end screen)" << endl;
  
  bool play = 1;
  while(play){
    
    if(counter > 0){
      cout << "Choose another story!" << endl << "Type 1 for \"Food Day\"" << endl << "Type 2 for \"Summer Love Story\"" << endl << "Type 3 for \"STORY3\"" << endl << "(Type 4 to skip to end screen)" << endl;
    }
    cin >> stories;
    
    switch (stories) {
      case 1:
        for(int i = 1; getline(file, line) && i < 4; i++){
          if(i == 1){
            story = line;
          }
        }
      case 2:
        for(int i = 1; getline(file, line) && i < 4; i++){
          if(i == 2){
            story = line;
          }
        }
      case 3:
        for(int i = 1; getline(file, line) && i < 4; i++){
          if(i == 3){
            story = line;
          }
        }
    }

    counter++;
    if(stories == 1){ 
      cout << "As the prompts come up, fill each with a random word to fill the blanks and allow hilarity to ensue." << endl;
      wordnum = 8;
      
      cout << "Type a food: ";
      cin >> words[0];
      replaceWord(story, "FOOD", 4, words[0]);
      
      cout << "Type a name: ";
      cin >> words[1];
      replaceWord(story, "NAME", 4, words[1]);
      
      cout << "Type an emotion: ";
      cin >> words[2];
      replaceWord(story, "EMOTION", 7, words[2]);
      
      cout << "Type a noun: ";
      cin >> words[3];
      replaceWord(story, "NOUN1", 5, words[3]);
      
      cout << "Type another noun: ";
      cin >> words[7];
      replaceWord(story, "NOUN2", 5, words[7]);
      
      cout << "Type a past-tense verb: ";
      cin >> words[4];
      replaceWord(story, "VERB1", 5, words[4]);
      
      cout << "Type another past-tense verb: ";
      cin >> words[5];
      replaceWord(story, "VERB2", 5, words[5]);
      
      cout << "Type another past-tense verb: ";
      cin >> words[6];
      replaceWord(story, "VERB3", 5, words[6]);
      
      cout << endl << story << endl;
      
    }else if(stories == 2){
      cout << "As the prompts come up, fill each with a random word to fill the blanks and allow hilarity to ensue." << endl;
      wordnum = 20;
      cout << "Type a guy's name: ";
      cin >> words[0];
      replaceWord(story, "NAME1", 5, words[0]);
      
      cout << "Type a girl's name: ";
      cin >> words[1];
      replaceWord(story, "NAME2", 5, words[1]);
      
      cout << "Type a noun: ";
      cin >> words[2];
      replaceWord(story, "NOUN1", 5, words[2]);
      
      cout << "Type another noun: ";
      cin >> words[4];
      replaceWord(story, "NOUN2", 5, words[4]);
      
      cout << "Type a proper noun: ";
      cin >> words[11];
      replaceWord(story, "NOUN3", 5, words[11]);

    
    }else if(stories == 3){
      // cout << "As the prompts come up, fill each with a random word to fill the blanks and allow hilarity to ensue." << endl;
      cout << "Under construction!" << endl;
    }else if(stories == 4){
      cout << "Skipped!\n";
    }else{
      cout << "Invalid response, try again!\n";
    }

    if(counter > 0){
      cout << endl << "Would you like to try another story? (Y/N)\n";
      char yn;
      cin >> yn;
      if(yn == 'Y'||yn == 'y'){
        cout << endl;
        counter++;
      }else if(yn == 'N'||yn == 'n'){
        play = 0;
      }else{
        cout << "Invalid response, try again!\n";
      }
    }
  }
  cout << " ____    ____               __  _____      _   __\n";
  cout << "|_   \\  /   _|             |  ]|_   _|    (_) [  |\n";
  cout << "  |   \\/   |   ,--.    .--.| |   | |      __   | |.--.   .--.\n";
  cout << "  | |\\  /| |  `'_\\ : / /'`\\' |   | |   _ [  |  | '/'`\\ \\( (`\\]\n";
  cout << " _| |_\\/_| |_ // | |,| \\__/  |  _| |__/ | | |  |  \\__/ | `'.'.\n";
  cout << "|_____||_____|\\'-;__/ '.__.;__]|________|[___][__;.__.' [\\__) )\n";
  cout << "Thanks for playing!\nCreated by Duncan Kyle 2022. Mad Libs stories found online, all rights reserved.";
  return 0;
}